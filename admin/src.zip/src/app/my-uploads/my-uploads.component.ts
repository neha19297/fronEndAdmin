import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-uploads',
  templateUrl: './my-uploads.component.html',
  styleUrls: ['./my-uploads.component.scss']
})
export class MyUploadsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
