import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teachers-que-bank',
  templateUrl: './teachers-que-bank.component.html',
  styleUrls: ['./teachers-que-bank.component.scss']
})
export class TeachersQueBankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
